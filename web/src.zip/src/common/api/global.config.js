export default {
    whiteListApi: ['/404', '/error'],
    secretId: 'tms'
}