export default {
    xAixs: {}
}