<template>
    <div>弹窗组件</div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
