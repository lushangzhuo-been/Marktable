export default {
    noGroupInfo: {
        id: 0,
        ws_id: 0,
        tmpl_id: 0,
        field_key: "",
        name: "无分组",
        desc: "",
        mode: "",
        enum_values: "",
        expr: "",
        level: "",
        read_only_rule: "",
        related_tmpl_id: 0
    }
};
