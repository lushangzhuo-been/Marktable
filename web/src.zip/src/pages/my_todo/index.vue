<template>
    <div>
        <div class="title">我的待办</div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            title: '登录页',
        }
    },
}
</script>

<style lang="scss" scoped>
.mu-index {
}
</style>
